﻿using System.Windows;

namespace PrivateDoctorsApp.View.Doctor
{
    /// <summary>
    /// Interaction logic for ChangeScheduleWindow.xaml
    /// </summary>
    public partial class ChangeScheduleWindow : Window
    {
        public ChangeScheduleWindow()
        {
            InitializeComponent();
        }
    }
}
