﻿using System.Windows;

namespace PrivateDoctorsApp.View.Doctor
{
    /// <summary>
    /// Interaction logic for DeleteScheduleWindow.xaml
    /// </summary>
    public partial class DeleteScheduleWindow : Window
    {
        public DeleteScheduleWindow()
        {
            InitializeComponent();
        }
    }
}
