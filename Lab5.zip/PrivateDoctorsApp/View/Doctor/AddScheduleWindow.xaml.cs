﻿using System.Windows;

namespace PrivateDoctorsApp.View.Doctor
{
    /// <summary>
    /// Interaction logic for AddScheduleWindow.xaml
    /// </summary>
    public partial class AddScheduleWindow : Window
    {
        public AddScheduleWindow()
        {
            InitializeComponent();
        }
    }
}
