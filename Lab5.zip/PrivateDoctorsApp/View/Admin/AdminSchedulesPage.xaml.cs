﻿using System.Windows.Controls;

namespace PrivateDoctorsApp.View.Admin
{
    /// <summary>
    /// Interaction logic for AdminSchedulesPage.xaml
    /// </summary>
    public partial class AdminSchedulesPage : Page
    {
        public AdminSchedulesPage()
        {
            InitializeComponent();
        }
    }
}
