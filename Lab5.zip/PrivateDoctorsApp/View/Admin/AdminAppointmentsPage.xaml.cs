﻿using System.Windows.Controls;

namespace PrivateDoctorsApp.View.Admin
{
    /// <summary>
    /// Interaction logic for AdminAppointmentsPage.xaml
    /// </summary>
    public partial class AdminAppointmentsPage : Page
    {
        public AdminAppointmentsPage()
        {
            InitializeComponent();
        }
    }
}
