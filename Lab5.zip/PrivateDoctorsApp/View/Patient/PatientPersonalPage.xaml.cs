﻿using System.Windows.Controls;

namespace PrivateDoctorsApp.View.Patient
{
    /// <summary>
    /// Interaction logic for PatientPersonalPage.xaml
    /// </summary>
    public partial class PatientPersonalPage : Page
    {
        public PatientPersonalPage()
        {
            InitializeComponent();
        }
    }
}
