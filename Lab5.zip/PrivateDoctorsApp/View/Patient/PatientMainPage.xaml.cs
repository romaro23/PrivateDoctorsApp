﻿using System.Windows.Controls;
using PrivateDoctorsApp.ViewModel;

namespace PrivateDoctorsApp.View.Patient
{
    /// <summary>
    /// Interaction logic for PatientMainPage.xaml
    /// </summary>
    public partial class PatientMainPage : Page
    {
        public PatientMainPage()
        {
            InitializeComponent();
            DataContext = new PatientMainPageViewModel();
        }
    }
}
